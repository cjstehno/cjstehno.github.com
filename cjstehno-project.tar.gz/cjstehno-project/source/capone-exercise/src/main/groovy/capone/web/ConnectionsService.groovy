/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone.web

import capone.Connections
import capone.Person
import groovy.transform.CompileStatic
import groovy.transform.Memoized
import org.springframework.stereotype.Service

/**
 * Service used to provide web access to the connections library.
 */
@CompileStatic @Service
class ConnectionsService {

    private final Connections connections = new Connections()
        .loadPeople(ConnectionsService.getResourceAsStream('/Person.txt'))
        .loadRelationships(ConnectionsService.getResourceAsStream('/Relationship.txt'))

    /**
     * Provides a sorted list of all the people configured in the system. The results of this method are cached after the first call.
     *
     * @return a sorted list of people.
     */
    @Memoized(protectedCacheSize = 1, maxCacheSize = 1)
    List<Person> people() {
        connections.listPeople().sort()
    }

    /**
     * Used to answer the questions given the specified input data.
     *
     * @param form the input data
     * @return the answers to the questions
     */
    ConnectionsAnswers answerQuestions(final QuestionsForm form) {
        new ConnectionsAnswers(
            connections.totalConnections(form.question1),
            connections.commonPeople(form.question2_a, form.question2_b),
            connections.countConnectionsBetween(form.question3_a, form.question3_b),
            connections.findMostConnected(),
            connections.findLeastConnected()
        )
    }
}

