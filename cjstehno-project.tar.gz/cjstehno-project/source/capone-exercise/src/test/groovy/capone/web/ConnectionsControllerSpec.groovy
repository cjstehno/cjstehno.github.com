/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone.web

import capone.Person
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult
import org.springframework.validation.BindingResult
import spock.lang.Specification

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup

class ConnectionsControllerSpec extends Specification {

    private final ConnectionsService connectionsService = new ConnectionsService()

    private final ConnectionsController controller = new ConnectionsController(
        connectionsService: connectionsService
    )

    private final MockMvc mvc = standaloneSetup(controller).build()

    def 'show the index view'() {
        when:
        MvcResult result = mvc.perform(get('/')).andReturn()

        then:
        result.response.status == 200
        result.modelAndView.viewName == 'index'
        result.modelAndView.model.answers == new ConnectionsAnswers(
            99,
            [new Person(95, 'Asher'), new Person(81, 'Xavier'), new Person(53, 'Dominic'), new Person(28, 'Henry'), new Person(37, 'Grayson')] as Set<Person>,
            4,
            new Tuple2<Person, Integer>(new Person(61, 'Levi'), 27),
            new Tuple2<Person, Integer>(new Person(20, 'William'), 13)
        )
        result.modelAndView.model.form == new QuestionsForm(4, 4, 62, 4, 63)
        result.modelAndView.model.people.size() == 100
        (result.modelAndView.model['org.springframework.validation.BindingResult.answers'] as BindingResult).errorCount == 0
        (result.modelAndView.model['org.springframework.validation.BindingResult.form'] as BindingResult).errorCount == 0
    }

    def 'update the question/answers'() {
        when:
        MvcResult result = mvc.perform(
            post('/').contentType(MediaType.APPLICATION_FORM_URLENCODED).param('question1', '10')
                .param('question2_a', '42').param('question2_b', '99')
                .param('question3_a', '15').param('question3_b', '16')
        ).andReturn()

        then:
        result.response.status == 200
        result.modelAndView.viewName == 'index'
        result.modelAndView.model.answers == new ConnectionsAnswers(
            99,
            [new Person(54, 'Anthony'), new Person(55, 'Colton')] as Set<Person>,
            6,
            new Tuple2<Person, Integer>(new Person(61, 'Levi'), 27),
            new Tuple2<Person, Integer>(new Person(20, 'William'), 13)
        )
        result.modelAndView.model.form == new QuestionsForm(10, 42, 99, 15, 16)
        result.modelAndView.model.people.size() == 100
        (result.modelAndView.model['org.springframework.validation.BindingResult.answers'] as BindingResult).errorCount == 0
        (result.modelAndView.model['org.springframework.validation.BindingResult.form'] as BindingResult).errorCount == 0
    }
}
