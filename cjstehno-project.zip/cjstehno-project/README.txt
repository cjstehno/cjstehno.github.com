Candidate Coding Assignment for Christopher J. Stehno

The questions and answers are below:

1. How many total connections Lucas(id=4) has?
    99

2. Who can introduce Lucas to Adam(id=62)
    28: Henry
    37: Grayson
    53: Dominic
    81: Xavier
    95: Asher

3. How many connections are there between two users. 
    Depends on person, some examples:

    Between Jackson (1) and Samuel (42) there are 2.
    Between Elijah (18) and Samuel (42) there are 3.
    Between Mateo (98) and Jonathan (76) there are 6.

4. Which user has highest connections
    Levi (61) has the highest number of connections (27).

5. Which user has lowest connections
    William (20) has the fewest connections (13).

There is also a web-based interface to the questions (requires Java 8) - see the project source README.md file for details on how to build and run it - the compiled artifact was too big to include via email.

The complete project can be found in the "source" directory. The QuestionSpec test in the project contains the code used to determine the answers.
