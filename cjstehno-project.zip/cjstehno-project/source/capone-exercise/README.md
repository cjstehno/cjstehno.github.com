# capone-exercise

Capital One coding exercise

## Specification

There are two data sets.

* One file contains list of 100 people and their names. 
* 2nd file has the relationship of each person with at least 5 other folks on the list. 

You are free to use any language. Take your time to go through this exercise. 
 
Here are the questions that your program needs to answer:
 
1. How many total connections  Lucas(id=4) has?
2. Who can introduce Lucas to Adam(id=62)
3. How many connections are there between two users. 
4. Which user has highest connections
5. Which user has lowest connections
 
*Bonus* would be if you could build a web interface to change inputs for each of these questions.

## Answers

The answers to the questions are proven in the `QuestionsSpec` class.

### 1. How many total connections Lucas(id=4) has?

100

### 2. Who can introduce Lucas to Adam(id=62)

28: Henry
37: Grayson
53: Dominic
81: Xavier
95: Asher

### 3. How many connections are there between two users. 

Depends on person, some examples:

Between Jackson (1) and Samuel (42) there are 2.
Between Elijah (18) and Samuel (42) there are 3.
Between Mateo (98) and Jonathan (76) there are 6.

### 4. Which user has highest connections

Levi (61) has the highest number of connections (27).

### 5. Which user has lowest connections

William (20) has the fewest connections (13).

## Building

The project is built with Gradle. To build it locally, navigate into the project directory and run:

    ./gradlew clean build
    
which will build the project and run the tests.

You can view the test results on the console or in the HTML report (open `./build/reports/tests/test/index.html` in a browser).

## Web Interface

There is also a simple Spring-boot web interface. The `./build/libs/capone-exercise-0.0.1.jar` file is an executable standalone web application. Run
it using:

    java -jar capone-exercise-0.0.1.jar
    
And then, once the application starts, open your browser to http://localhost:8080 for the web interface.