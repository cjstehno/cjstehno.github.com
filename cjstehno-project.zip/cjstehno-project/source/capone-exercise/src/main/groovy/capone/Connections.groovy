/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone

import com.google.common.graph.GraphBuilder
import com.google.common.graph.MutableGraph
import groovy.util.logging.Slf4j

import static com.google.common.graph.Graphs.reachableNodes

/**
 * Utility for loading a dataset of people and their relationships to determine connections between them.
 */
@Slf4j
class Connections {

    private final MutableGraph<Person> graph = GraphBuilder.undirected().allowsSelfLoops(false).build()

    /**
     * Loads the dataset containing the people in the system. This dataset must be loaded before the relationships.
     *
     * The data should be one person per line containing the id number and name separated by a tab character.
     *
     * @param stream the stream of dataset data.
     * @return a reference to this object for chaining
     */
    Connections loadPeople(final InputStream stream) {
        log.info 'Loading people...'

        stream.eachLine { String line ->
            if (line.trim()) {
                def (String id, String name) = line.split('\t')
                graph.addNode(new Person(id as Integer, name))
            }
        }

        log.info 'Loaded {} people.', peopleCount

        this
    }

    /**
     * Loads the dataset containing the relationships. This dataset must be loaded after the people have been loaded. If not,
     * an IllegalArgumentException will be thrown.
     *
     * The dataset should be formatted as one relationship set per line with the person id number followed by a colon, and then
     * a comma-separated list of connections.
     *
     * @param stream the stream of dataset data
     * @return a reference to this object for chaining
     */
    Connections loadRelationships(final InputStream stream) {
        if (!peopleCount) {
            throw new IllegalArgumentException('There are no people loaded - load people before loading relationships.')
        }

        log.info 'Loading relationships...'

        int count = 0
        stream.eachLine { String line ->
            if (line.trim()) {
                def (String id, String relations) = line.trim().split(': ')

                int pid = id as Integer
                Person person = getPerson(pid)

                relations.split(',').collect { r -> r as Integer }.unique().each { Integer relid ->
                    if (relid != pid) {
                        graph.putEdge(person, getPerson(relid))
                    }
                }

                count++
            }
        }

        log.info 'Loaded relationships for {} people.', count

        this
    }

    /**
     * Retrieves a count of the number of people in the system.
     *
     * @return a count of the number of people
     */
    int getPeopleCount() {
        graph.nodes().size()
    }

    /**
     * Used to retrieve a list of all people configured in the system.
     * @return
     */
    List<Person> listPeople() {
        new ArrayList<>(graph.nodes())
    }

    /**
     * Retrieves the Person object associated with the given id. If no Person exists for that id value, an IllegalArgumentException
     * is thrown.
     *
     * @param id the person id
     * @return the Person with the specified id (if exists)
     */
    Person getPerson(final int id) {
        Person person = graph.nodes().find { n -> n.id == id }

        if (!person) {
            throw new IllegalArgumentException("No person exists for the specified id ($id).")
        }

        person
    }

    /**
     * Retrieves a count of the total number of connections for a person with the specified id.
     *
     * @param id the person id
     * @return the total number of connections for the person
     */
    int totalConnections(final int id) {
        Math.max(0, reachableNodes(graph, getPerson(id)).size() - 1)
    }

    /**
     * Retrieves the set of people that the two specified people have in common.
     *
     * @param pidA the id for the first person
     * @param pidB the id for the second person
     * @return the set of people in-common
     */
    Set<Person> commonPeople(final int pidA, final int pidB) {
        graph.adjacentNodes(getPerson(pidA)).intersect(graph.adjacentNodes(getPerson(pidB)))
    }

    /**
     * Retrieves the number of connections between two people.
     *
     * @param pidA the first person
     * @param pidB the second person
     * @return the count of common connections
     */
    int countConnectionsBetween(final int pidA, final int pidB) {
        commonPeople(pidA, pidB).size()
    }

    /**
     * Used to find the person in the system with the most connections.
     *
     * @return a tuple containing the Person with the most connections and the connection count.
     */
    Tuple2<Person, Integer> findMostConnected() {
        Person most = graph.nodes().max { n ->
            graph.adjacentNodes(n).size()
        }

        [most, graph.adjacentNodes(most).size()]
    }

    /**
     * Used to find the person in the system with the least connections.
     *
     * @return a tuple containing the Person with the least connections and the connection count.
     */
    Tuple2<Person, Integer> findLeastConnected() {
        Person least = graph.nodes().min { n ->
            graph.adjacentNodes(n).size()
        }

        [least, graph.adjacentNodes(least).size()]
    }
}
