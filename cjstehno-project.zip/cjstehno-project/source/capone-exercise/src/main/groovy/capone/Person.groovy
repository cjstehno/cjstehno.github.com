/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone

import groovy.transform.Canonical
import groovy.transform.CompileStatic
import groovy.transform.Sortable
import groovy.transform.ToString

/**
 * Representation of a person data in the system.
 */
@CompileStatic @Canonical @ToString(includeNames = true, includePackage = false)
@Sortable(includes = ['name'])
class Person {

    /**
     * The id number of the person record.
     */
    Integer id

    /**
     * The name of the person.
     */
    String name
}
