/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone.web

import groovy.transform.CompileStatic
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.servlet.ModelAndView

import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED_VALUE
import static org.springframework.http.MediaType.TEXT_HTML_VALUE

/**
 * Endpoint controller for the connections application.
 */
@CompileStatic @Controller @SuppressWarnings('GroovyUnusedDeclaration')
class ConnectionsController {

    @Autowired private ConnectionsService connectionsService

    @GetMapping('/')
    ModelAndView index() {
        renderIndex new QuestionsForm()
    }

    @PostMapping(value = '/', consumes = [APPLICATION_FORM_URLENCODED_VALUE], produces = [TEXT_HTML_VALUE])
    ModelAndView update(QuestionsForm questionsForm) {
        renderIndex questionsForm
    }

    private ModelAndView renderIndex(final QuestionsForm form) {
        new ModelAndView('index', [
            people : connectionsService.people(),
            form   : form,
            answers: connectionsService.answerQuestions(form)
        ])
    }
}

