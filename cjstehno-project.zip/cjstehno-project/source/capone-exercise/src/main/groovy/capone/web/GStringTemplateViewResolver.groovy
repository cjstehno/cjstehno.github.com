/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone.web

import groovy.text.GStringTemplateEngine
import groovy.text.Template
import groovy.text.TemplateEngine
import groovy.transform.CompileStatic
import groovy.transform.TupleConstructor
import groovy.util.logging.Slf4j
import org.springframework.http.MediaType
import org.springframework.web.servlet.View
import org.springframework.web.servlet.view.AbstractCachingViewResolver

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

/**
 * A simple view resolver that uses the Groovy GStringTemplateEngine for rendering.
 */
@CompileStatic @Slf4j
class GStringTemplateViewResolver extends AbstractCachingViewResolver {

    private final TemplateEngine engine = new GStringTemplateEngine()

    @Override
    protected View loadView(final String viewName, final Locale locale) throws Exception {
        log.info 'Loading view ({})...', viewName

        new GStringTemplateView(engine.createTemplate(GStringTemplateViewResolver.getResource("/templates/${viewName}.html")))
    }

    @CompileStatic @TupleConstructor
    private static class GStringTemplateView implements View {

        final Template template

        @Override
        String getContentType() {
            MediaType.TEXT_HTML_VALUE
        }

        @Override
        void render(final Map<String, ?> model, final HttpServletRequest request, final HttpServletResponse response) throws Exception {
            response.writer.write(template.make(model))
        }
    }
}