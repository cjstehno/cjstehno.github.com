/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone

import spock.lang.Specification

class ConnectionsSpec extends Specification {

    private final Connections connections = new Connections()

    def 'loading people'() {
        when:
        connections.loadPeople(ConnectionsSpec.getResourceAsStream('/Person.txt'))

        then:
        connections.peopleCount == 100
        connections.getPerson(12).name == 'Logan'
        connections.getPerson(42).name == 'Samuel'
    }

    def 'loading people (blank entry lines)'() {
        when:
        connections.loadPeople(new ByteArrayInputStream('''5\tNoah
        
        8\tEthan
        
        '''.stripMargin().bytes))

        then:
        connections.peopleCount == 2
        connections.getPerson(5).name == 'Noah'
        connections.getPerson(8).name == 'Ethan'
    }

    def 'loading connections (without people)'() {
        when:
        connections.loadRelationships(ConnectionsSpec.getResourceAsStream('/Relationship.txt'))

        then:
        def ex = thrown(IllegalArgumentException)
        ex.message == 'There are no people loaded - load people before loading relationships.'
    }

    def 'loading connections'() {
        setup:
        connections.loadPeople(ConnectionsSpec.getResourceAsStream('/Person.txt'))

        when:
        connections.loadRelationships(ConnectionsSpec.getResourceAsStream('/Relationship.txt'))

        then:
        connections.totalConnections(12) == 99
        connections.totalConnections(42) == 99
    }

    def 'loading connections (with blank lines)'() {
        setup:
        connections.loadPeople(ConnectionsSpec.getResourceAsStream('/Person.txt'))

        when:
        connections.loadRelationships(new ByteArrayInputStream(''' 43: 26, 27, 30, 41, 45, 51, 59, 66, 82, 99

         44: 10, 15, 18, 27, 33, 39, 57, 61, 62, 85

        '''.stripMargin().bytes))

        then:
        connections.totalConnections(12) == 0
        connections.totalConnections(43) == 20
        connections.totalConnections(44) == 20
    }
}
