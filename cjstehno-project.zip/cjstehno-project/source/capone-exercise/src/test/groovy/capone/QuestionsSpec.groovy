/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone

import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class QuestionsSpec extends Specification {

    @Shared
    private Connections connections = new Connections()
        .loadPeople(ConnectionsSpec.getResourceAsStream('/Person.txt'))
        .loadRelationships(ConnectionsSpec.getResourceAsStream('/Relationship.txt'))

    def '1. How many total connections Lucas(id=4) has?'() {
        when:
        int totalConnections = connections.totalConnections(4)

        then:
        totalConnections == 99
    }

    def '2. Who can introduce Lucas(id=4) to Adam(id=62)'() {
        when:
        Set<Person> introducers = connections.commonPeople(4, 62)

        then:
        introducers.size() == 5
        introducers.contains new Person(28, 'Henry')
        introducers.contains new Person(37, 'Grayson')
        introducers.contains new Person(53, 'Dominic')
        introducers.contains new Person(81, 'Xavier')
        introducers.contains new Person(95, 'Asher')
    }

    @Unroll '3. How many connections are there between two users (#personA and #personB)'() {
        expect:
        connections.countConnectionsBetween(personA, personB) == count

        where:
        personA | personB || count
        1       | 42      || 2
        18      | 42      || 3
        98      | 76      || 6
    }

    def '4. Which user has highest connections'() {
        when:
        def (Person person, Integer count) = connections.findMostConnected()

        then:
        person == new Person(61, 'Levi')
        count == 27
    }

    def '5. Which user has lowest connections'() {
        when:
        def (Person person, Integer count) = connections.findLeastConnected()

        then:
        person == new Person(20, 'William')
        count == 13
    }
}
