/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <https://unlicense.org>
 */
package capone.web

import capone.Person
import spock.lang.Shared
import spock.lang.Specification

class ConnectionsServiceSpec extends Specification {

    @Shared
    private ConnectionsService service = new ConnectionsService()

    def 'list people'(){
        when:
        List<Person> people = service.people()

        then:
        people.size() == 100
        people.unique().size() == 100
    }

    def 'answer questions'(){
        when:
        ConnectionsAnswers answers = service.answerQuestions(new QuestionsForm(1,2,3,4,5))

        then:
        answers == new ConnectionsAnswers(
            99,
            [new Person(47, 'Cameron'), new Person(66, 'Parker'), new Person(53, 'Dominic')] as Set<Person>,
            4,
            new Tuple2<Person, Integer>(new Person(61, 'Levi'), 27),
            new Tuple2<Person, Integer>(new Person(20, 'William'), 13)
        )
    }
}
